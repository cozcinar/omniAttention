# Dataset files



## Parameters

* time = playing time of the video (second)
* u = u texture coordinate for the middle point of the viewport
* v = v texture coordinate for the middle point of the viewport

More info can be found in https://v-sense.scss.tcd.ie/?p=1994 or https://github.com/cozcinar/omniAttention

*Please cite our paper in your publications if it helps your research:

@inproceedings{Ozcinar2018,
title = {Visual Attention in Omnidirectional Video for Virtual Reality Applications},
author = {Cagri Ozcinar and Aljosa Smolic},
year = {2018},
booktitle = {10th International Conference on Quality of Multimedia Experience (QoMEX 2018)}
}

*Contact
If you have any question, please do not hassisate to contact me: *ozcinarc@scss.tcd.ie* or *cagriozcinar@gmail.com*